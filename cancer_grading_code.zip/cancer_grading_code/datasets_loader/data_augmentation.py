import torch
import random
from torchvision import transforms


def get_transforms(mean=None, std=None, resize_size=None, random_crop_size=None):
    transforms_list = [transforms.ToTensor()]
    if (mean is not None) and (std is not None):
        transforms_list.append(transforms.Normalize(mean=mean, std=std))

    if resize_size is not None:
        transforms_list.append(transforms.Resize(resize_size, antialias=True))

    if random_crop_size is not None:
        transforms_list.append(transforms.RandomCrop(random_crop_size))

    return transforms.Compose(transforms_list)


def random_crop(img_list, crop_size=None):

    if crop_size is None:
        return img_list

    if len(crop_size) == 1:
        crop_w = crop_size[0]
        crop_h = crop_size[0]
    elif len(crop_size) == 2:
        crop_w = crop_size[0]
        crop_h = crop_size[1]
    else:
        return img_list

    c, w, h = img_list[0].shape
    w_random = random.randint(0, (w - crop_w))
    h_random = random.randint(0, (h - crop_h))
    crop_img_list = []
    for img in img_list:
        crop_img_list.append(img[:, w_random:(w_random + crop_w), h_random:(h_random + crop_h)])

    return crop_img_list


def center_crop(img_list, crop_size=None):

    if crop_size is None:
        return img_list

    if len(crop_size) == 1:
        crop_w = crop_size[0]
        crop_h = crop_size[0]
    elif len(crop_size) == 2:
        crop_w = crop_size[0]
        crop_h = crop_size[1]
    else:
        return img_list

    c, w, h = img_list[0].shape
    w_start = int((w - crop_w) / 2)
    h_start = int((h - crop_h) / 2)

    crop_img_list = []
    for img in img_list:
        crop_img_list.append(img[:, w_start:(w_start + crop_w), h_start:(h_start + crop_h)])

    return crop_img_list


def img_augmentation(img_list, crop_size=None, crop_type='random'):

    if 'random' == crop_type:
        augmentation_list = random_crop(img_list, crop_size)
    elif 'center' == crop_type:
        augmentation_list = center_crop(img_list, crop_size)
    else:
        raise Exception(f'Crop type not supported: {crop_type}')

    random_num = random.choice([0, 1, 2, 3, 4, 5, 6, 7])
    # 0 则原样返回
    for idx in range(len(augmentation_list)):
        if 1 == random_num:
            augmentation_list[idx] = torch.flip(augmentation_list[idx], dims=[1])
        elif 2 == random_num:
            augmentation_list[idx] = torch.flip(augmentation_list[idx], dims=[2])
        elif 3 == random_num:
            augmentation_list[idx] = torch.rot90(augmentation_list[idx], k=1, dims=[1, 2])
        elif 4 == random_num:
            augmentation_list[idx] = torch.rot90(augmentation_list[idx], k=2, dims=[1, 2])
        elif 5 == random_num:
            augmentation_list[idx] = torch.rot90(augmentation_list[idx], k=3, dims=[1, 2])
        elif 6 == random_num:
            augmentation_list[idx] = torch.rot90(torch.flip(augmentation_list[idx], dims=[1]), k=1, dims=[1, 2])
        elif 7 == random_num:
            augmentation_list[idx] = torch.rot90(torch.flip(augmentation_list[idx], dims=[1]), k=3, dims=[1, 2])

    return augmentation_list
