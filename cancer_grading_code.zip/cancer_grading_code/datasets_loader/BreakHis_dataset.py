import torch
from torch.utils.data import Dataset
import os
from PIL import Image

from datasets_loader.data_augmentation import get_transforms, img_augmentation

# Train set mean and std
mean_dict = {'original': (0.767555, 0.579614, 0.711253),
             'eosin': (0.982145, 0.784785, 0.972112),
             'hematoxylin': (0.843772, 0.834821, 0.919760)}
std_dict = {'original': (0.204222, 0.249074, 0.188245),
            'eosin': (0.011596, 0.127888, 0.017911),
            'hematoxylin': (0.190308, 0.199471, 0.104823)}

default_img_size = [700, 460]  # [700, 460]


class BreakHisDataset400X(Dataset):
    '''
    BreakHis WSIs Dataset: BreakHis 400X
    '''
    def __init__(self, images_dir, modality_list):
        super(BreakHisDataset400X, self).__init__()
        self.images_dir = images_dir
        self.modality_list = modality_list
        self.transform_original = get_transforms(# mean=mean_dict['original'],
                                                 # std=std_dict['original'],
                                                 resize_size=default_img_size,
                                                 random_crop_size=None)
        self.transform_eosin = get_transforms(# mean_dict['eosin'],
                                              # std_dict['eosin'],
                                              resize_size=default_img_size,
                                              random_crop_size=None)
        self.transform_hematoxylin = get_transforms(# mean_dict['hematoxylin'],
                                                    # std_dict['hematoxylin'],
                                                    resize_size=default_img_size,
                                                    random_crop_size=None)
        self.images_list = self.read_file(images_dir)

    def __len__(self):
        return len(self.images_list)

    def __getitem__(self, idx):
        name = self.images_list[idx][0]
        label = self.images_list[idx][1]

        label_name = 'benign'
        if 1 == label:
            label_name = 'malignant'

        seed = torch.random.seed()

        torch_cat_list = []
        if 'original' in self.modality_list:
            torch.random.manual_seed(seed)
            image_original = self.transform_original(
                Image.open(os.path.join(self.images_dir, label_name, 'original', name)).convert('RGB'))
            torch_cat_list.append(image_original)
        if 'eosin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_eosin = self.transform_eosin(
                Image.open(os.path.join(self.images_dir, label_name, 'eosin', name)).convert('RGB'))
            torch_cat_list.append(image_eosin)
        if 'hematoxylin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_hematoxylin = self.transform_hematoxylin(
                Image.open(os.path.join(self.images_dir, label_name, 'hematoxylin', name)).convert('RGB'))
            torch_cat_list.append(image_hematoxylin)

        torch_cat_list = img_augmentation(torch_cat_list)

        for i in range(len(torch_cat_list)):
            torch_cat_list[i] = torch_cat_list[i].unsqueeze(0)

        return torch.cat(torch_cat_list, dim=0), label, name

    def read_file(self, images_dir):
        sub_folders = ['benign', 'malignant']
        images_label_list = []
        for label_name in sub_folders:
            label_num = 0
            if 'malignant' == label_name:
                label_num = 1
            img_path = os.path.join(images_dir, label_name, 'original')
            for img_name in os.listdir(img_path):
                images_label_list.append([img_name, label_num])
        return images_label_list


class BreakHisDataset(Dataset):
    def __init__(self, images_dir, modality_list, label_file):
        super(BreakHisDataset, self).__init__()
        self.images_dir = images_dir
        self.modality_list = modality_list
        self.transform_original = get_transforms(mean=mean_dict['original'],
                                                 std=std_dict['original'],
                                                 resize_size=default_img_size,
                                                 random_crop_size=None)
        self.transform_eosin = get_transforms(mean_dict['eosin'],
                                              std_dict['eosin'],
                                              resize_size=default_img_size,
                                              random_crop_size=None)
        self.transform_hematoxylin = get_transforms(mean_dict['hematoxylin'],
                                                    std_dict['hematoxylin'],
                                                    resize_size=default_img_size,
                                                    random_crop_size=None)
        self.images_list = self.read_file(label_file)

    def __len__(self):
        return len(self.images_list)

    def __getitem__(self, idx):
        name = self.images_list[idx][0]
        label = self.images_list[idx][1]

        seed = torch.random.seed()
        torch_cat_list = []
        if 'original' in self.modality_list:
            torch.random.manual_seed(seed)
            image_original = self.transform_original(
                Image.open(os.path.join(self.images_dir, 'original', name)).convert('RGB'))
            torch_cat_list.append(image_original)
        if 'eosin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_eosin = self.transform_eosin(
                Image.open(os.path.join(self.images_dir, 'eosin', name)).convert('RGB'))
            torch_cat_list.append(image_eosin)
        if 'hematoxylin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_hematoxylin = self.transform_hematoxylin(
                Image.open(os.path.join(self.images_dir, 'hematoxylin', name)).convert('RGB'))
            torch_cat_list.append(image_hematoxylin)

        torch_cat_list = img_augmentation(torch_cat_list, [256, 256])  # [460, 460], [400, 400], [256, 256]

        for i in range(len(torch_cat_list)):
            torch_cat_list[i] = torch_cat_list[i].unsqueeze(0)

        return torch.cat(torch_cat_list, dim=0), label, name

    def read_file(self, filename):
        images_label_list = []
        with open(filename, 'r') as f:
            lines = f.readlines()
            for line in lines:
                line = line.rstrip()
                name = line[:-2]
                label = line[-1]
                images_label_list.append([name, int(label)])
        return images_label_list


class BreakHisDatasetSupCon(Dataset):
    def __init__(self, images_dir, modality_list, label_file):
        super(BreakHisDatasetSupCon, self).__init__()
        self.images_dir = images_dir
        self.modality_list = modality_list
        self.transform_original = get_transforms(mean=mean_dict['original'],
                                                 std=std_dict['original'],
                                                 resize_size=default_img_size,
                                                 random_crop_size=None)
        self.transform_eosin = get_transforms(mean_dict['eosin'],
                                              std_dict['eosin'],
                                              resize_size=default_img_size,
                                              random_crop_size=None)
        self.transform_hematoxylin = get_transforms(mean_dict['hematoxylin'],
                                                    std_dict['hematoxylin'],
                                                    resize_size=default_img_size,
                                                    random_crop_size=None)
        self.images_list = self.read_file(label_file)

    def __len__(self):
        return len(self.images_list)

    def __getitem__(self, idx):
        name = self.images_list[idx][0]
        label = self.images_list[idx][1]

        seed = torch.random.seed()
        torch_cat_list = []
        if 'original' in self.modality_list:
            torch.random.manual_seed(seed)
            image_original = self.transform_original(
                Image.open(os.path.join(self.images_dir, 'original', name)).convert('RGB'))
            torch_cat_list.append(image_original)
        if 'eosin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_eosin = self.transform_eosin(
                Image.open(os.path.join(self.images_dir, 'eosin', name)).convert('RGB'))
            torch_cat_list.append(image_eosin)
        if 'hematoxylin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_hematoxylin = self.transform_hematoxylin(
                Image.open(os.path.join(self.images_dir, 'hematoxylin', name)).convert('RGB'))
            torch_cat_list.append(image_hematoxylin)

        torch_cat_list_1 = img_augmentation(torch_cat_list, [400, 400])
        torch_cat_list_2 = img_augmentation(torch_cat_list, [400, 400])

        for i in range(len(torch_cat_list)):
            torch_cat_list_1[i] = torch_cat_list_1[i].unsqueeze(0)
            torch_cat_list_2[i] = torch_cat_list_2[i].unsqueeze(0)

        return [torch.cat(torch_cat_list_1, dim=0), torch.cat(torch_cat_list_2, dim=0)], label, name

    def read_file(self, filename):
        images_label_list = []
        with open(filename, 'r') as f:
            lines = f.readlines()
            for line in lines:
                line = line.rstrip()
                name = line[:-2]
                label = line[-1]
                images_label_list.append([name, int(label)])
        return images_label_list
