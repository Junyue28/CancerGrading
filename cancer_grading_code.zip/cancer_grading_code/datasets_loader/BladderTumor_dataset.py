import torch
from torch.utils.data import Dataset
import os
from PIL import Image

from datasets_loader.data_augmentation import get_transforms, img_augmentation

# Train set mean and std
mean_dict = {'original': (0.843550, 0.682316, 0.784802),
             'eosin': (0.985829, 0.827535, 0.977849),
             'hematoxylin': (0.905971, 0.900577, 0.951799)}
std_dict = {'original': (0.182542, 0.238890, 0.179521),
            'eosin': (0.013176, 0.127999, 0.019813),
            'hematoxylin': (0.162619, 0.170552, 0.090086)}

default_img_size = [256, 256]


class BladderTumorDataset(Dataset):
    def __init__(self, images_dir, label_file_dir, modality_list):
        super(BladderTumorDataset, self).__init__()
        self.images_dir = images_dir
        self.modality_list = modality_list
        self.transform_original = get_transforms(mean=mean_dict['original'],
                                                 std=std_dict['original'],
                                                 resize_size=default_img_size,
                                                 random_crop_size=None)
        self.transform_eosin = get_transforms(mean_dict['eosin'],
                                              std_dict['eosin'],
                                              resize_size=default_img_size,
                                              random_crop_size=None)
        self.transform_hematoxylin = get_transforms(mean_dict['hematoxylin'],
                                                    std_dict['hematoxylin'],
                                                    resize_size=default_img_size,
                                                    random_crop_size=None)
        self.images_list = self.read_file(label_file_dir)

    def __len__(self):
        return len(self.images_list)

    def __getitem__(self, idx):
        name = self.images_list[idx][0]
        label = self.images_list[idx][1]

        seed = torch.random.seed()
        torch_cat_list = []
        if 'original' in self.modality_list:
            torch.random.manual_seed(seed)
            image_original = self.transform_original(
                Image.open(os.path.join(self.images_dir, 'original', name)).convert('RGB'))
            torch_cat_list.append(image_original)
        if 'eosin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_eosin = self.transform_eosin(
                Image.open(os.path.join(self.images_dir, 'eosin', name)).convert('RGB'))
            torch_cat_list.append(image_eosin)
        if 'hematoxylin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_hematoxylin = self.transform_hematoxylin(
                Image.open(os.path.join(self.images_dir, 'hematoxylin', name)).convert('RGB'))
            torch_cat_list.append(image_hematoxylin)

        torch_cat_list = img_augmentation(torch_cat_list, [256, 256])

        for i in range(len(torch_cat_list)):
            torch_cat_list[i] = torch_cat_list[i].unsqueeze(0)

        return torch.cat(torch_cat_list, dim=0), label, name

    def read_file(self, filename):
        images_label_list = []
        with open(filename, 'r') as f:
            lines = f.readlines()
            for line in lines:
                line = line.rstrip()
                name = line[:-2]
                label = line[-1]
                images_label_list.append([name, int(label)])
        return images_label_list


class BladderTumorDatasetSupCon(Dataset):
    def __init__(self, images_dir, label_file_dir, modality_list):
        super(BladderTumorDatasetSupCon, self).__init__()
        self.images_dir = images_dir
        self.modality_list = modality_list
        self.transform_original = get_transforms(mean=mean_dict['original'],
                                                 std=std_dict['original'],
                                                 resize_size=default_img_size,
                                                 random_crop_size=None)
        self.transform_eosin = get_transforms(mean_dict['eosin'],
                                              std_dict['eosin'],
                                              resize_size=default_img_size,
                                              random_crop_size=None)
        self.transform_hematoxylin = get_transforms(mean_dict['hematoxylin'],
                                                    std_dict['hematoxylin'],
                                                    resize_size=default_img_size,
                                                    random_crop_size=None)
        self.images_list = self.read_file(label_file_dir)

    def __len__(self):
        return len(self.images_list)

    def __getitem__(self, idx):
        name = self.images_list[idx][0]
        label = self.images_list[idx][1]

        seed = torch.random.seed()
        torch_cat_list = []
        if 'original' in self.modality_list:
            torch.random.manual_seed(seed)
            image_original = self.transform_original(
                Image.open(os.path.join(self.images_dir, 'original', name)).convert('RGB'))
            torch_cat_list.append(image_original)
        if 'eosin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_eosin = self.transform_eosin(
                Image.open(os.path.join(self.images_dir, 'eosin', name)).convert('RGB'))
            torch_cat_list.append(image_eosin)
        if 'hematoxylin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_hematoxylin = self.transform_hematoxylin(
                Image.open(os.path.join(self.images_dir, 'hematoxylin', name)).convert('RGB'))
            torch_cat_list.append(image_hematoxylin)

        torch_cat_list_1 = img_augmentation(torch_cat_list, [256, 256])
        torch_cat_list_2 = img_augmentation(torch_cat_list, [256, 256])

        for i in range(len(torch_cat_list)):
            torch_cat_list_1[i] = torch_cat_list_1[i].unsqueeze(0)
            torch_cat_list_2[i] = torch_cat_list_2[i].unsqueeze(0)

        return [torch.cat(torch_cat_list_1, dim=0), torch.cat(torch_cat_list_2, dim=0)], label, name

    def read_file(self, filename):
            images_label_list = []
            with open(filename, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    line = line.rstrip()
                    name = line[:-2]
                    label = line[-1]
                    images_label_list.append([name, int(label)])
            return images_label_list


def statistical_case_patch_num(folder_path):
    info_dic = {}

    for img_name in os.listdir(folder_path):
        case_name = img_name.split('_')[0]
        if case_name not in info_dic:
            info_dic[case_name] = 0
        else:
            info_dic[case_name] = info_dic[case_name] + 1

    print(len(info_dic))
    for key, value in info_dic.items():
        print('case_name: ', key, 'patch_num: ', value)
    return info_dic
