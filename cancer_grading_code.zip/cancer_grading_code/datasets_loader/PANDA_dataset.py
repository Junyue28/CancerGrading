import random
from tqdm import tqdm
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import cohen_kappa_score, accuracy_score
from torch.utils.data import Dataset
import os
from PIL import Image
import time
from datasets_loader.data_augmentation import get_transforms, img_augmentation, center_crop
# from tiatoolbox.tools import stainnorm
# from tiatoolbox.utils.misc import imread

# Train set mean and std
mean_dict = {'original': (0.831281, 0.652980, 0.764569),
             'eosin': (0.984219, 0.809105, 0.975346),
             'hematoxylin': (0.902365, 0.896633, 0.950456)}
std_dict = {'original': (0.174435, 0.242866, 0.178888),
            'eosin': (0.013213, 0.134679, 0.019999),
            'hematoxylin': (0.155450, 0.162858, 0.086690)}

default_img_size = [256, 256]


class PANDA_Dataset(Dataset):
    def __init__(self, images_dir, label_file_dir, modality_list, is_train=True, crop_img_size=None, is_SupCon=False):
        super(PANDA_Dataset, self).__init__()
        self.is_SupCon = is_SupCon
        if crop_img_size is None:
            crop_img_size = [256, 256]
        self.crop_img_size = crop_img_size
        self.images_dir = images_dir
        self.modality_list = modality_list

        self.transform_original = get_transforms(mean=mean_dict['original'],
                                                 std=std_dict['original'],
                                                 resize_size=self.crop_img_size,
                                                 random_crop_size=None)
        self.transform_eosin = get_transforms(mean_dict['eosin'],
                                              std_dict['eosin'],
                                              resize_size=self.crop_img_size,
                                              random_crop_size=None)
        self.transform_hematoxylin = get_transforms(mean_dict['hematoxylin'],
                                                    std_dict['hematoxylin'],
                                                    resize_size=self.crop_img_size,
                                                    random_crop_size=None)
        self.images_list = pd.read_csv(label_file_dir).values.tolist()
        self.is_train = is_train

    def __len__(self):
        return len(self.images_list)

    def __getitem__(self, idx):
        img_file_name = self.images_list[idx][0] + '.png'
        img_case_name = self.images_list[idx][1]
        label = int(self.images_list[idx][2]) - 1

        seed = torch.random.seed()
        torch_cat_list = []

        if 'original' in self.modality_list:
            torch.random.manual_seed(seed)
            image_original = self.transform_original(
                Image.open(os.path.join(self.images_dir, 'original', img_case_name, 'images', img_file_name)).convert('RGB'))
            torch_cat_list.append(image_original)
        if 'eosin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_eosin = self.transform_eosin(
                Image.open(os.path.join(self.images_dir, 'eosin', img_case_name, 'images', img_file_name)).convert('RGB'))
            torch_cat_list.append(image_eosin)
        if 'hematoxylin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_hematoxylin = self.transform_hematoxylin(
                Image.open(os.path.join(self.images_dir, 'hematoxylin', img_case_name, 'images', img_file_name)).convert('RGB'))
            torch_cat_list.append(image_hematoxylin)

        if self.is_SupCon:
            torch_cat_list_1 = img_augmentation(img_list=torch_cat_list, crop_size=self.crop_img_size,
                                                crop_type='random')
            torch_cat_list_2 = img_augmentation(img_list=torch_cat_list, crop_size=self.crop_img_size,
                                                crop_type='random')

            for i in range(len(torch_cat_list)):
                torch_cat_list_1[i] = torch_cat_list_1[i].unsqueeze(0)
                torch_cat_list_2[i] = torch_cat_list_2[i].unsqueeze(0)

            return [torch.cat(torch_cat_list_1, dim=0), torch.cat(torch_cat_list_2, dim=0)], label, img_file_name

        else:
            if self.is_train:
                torch_cat_list = img_augmentation(img_list=torch_cat_list, crop_size=self.crop_img_size,
                                                  crop_type='random')
            else:
                torch_cat_list = center_crop(img_list=torch_cat_list, crop_size=self.crop_img_size)

            for i in range(len(torch_cat_list)):
                torch_cat_list[i] = torch_cat_list[i].unsqueeze(0)

            return torch.cat(torch_cat_list, dim=0), label, img_file_name


def random_dict(dicts):
    dict_key_list = list(dicts.keys())
    random.shuffle(dict_key_list)
    new_dic = {}
    for key in dict_key_list:
        new_dic[key] = dicts.get(key)
    return new_dic
