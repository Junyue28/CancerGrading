import random

import pandas as pd
import torch
from torch.utils.data import Dataset
import os
from PIL import Image
import time
from datasets_loader.data_augmentation import get_transforms, img_augmentation


mean_dict = {'original': (0.779311, 0.587272, 0.718052),
             'eosin': (0.982078, 0.783298, 0.972006),
             'hematoxylin': (0.856336, 0.847849, 0.927219)}
std_dict = {'original': (0.191164, 0.239362, 0.180100),
            'eosin': (0.011327, 0.123409, 0.017518),
            'hematoxylin': (0.174122, 0.182697, 0.095432)}

default_img_size = [256, 256]


class GDC_Bladder_Tumor_Dataset(Dataset):
    def __init__(self, images_dir, label_file_dir, modality_list):
        super(GDC_Bladder_Tumor_Dataset, self).__init__()
        self.images_dir = images_dir
        self.modality_list = modality_list
        self.transform_original = get_transforms(mean=mean_dict['original'],
                                                 std=std_dict['original'],
                                                 resize_size=default_img_size,
                                                 random_crop_size=None)
        self.transform_eosin = get_transforms(mean_dict['eosin'],
                                              std_dict['eosin'],
                                              resize_size=default_img_size,
                                              random_crop_size=None)
        self.transform_hematoxylin = get_transforms(mean_dict['hematoxylin'],
                                                    std_dict['hematoxylin'],
                                                    resize_size=default_img_size,
                                                    random_crop_size=None)
        self.images_list = self.read_file(label_file_dir)

    def __len__(self):
        return len(self.images_list)

    def __getitem__(self, idx):
        name = self.images_list[idx][0]
        label = self.images_list[idx][1]

        seed = torch.random.seed()
        torch_cat_list = []
        if 'original' in self.modality_list:
            torch.random.manual_seed(seed)
            image_original = self.transform_original(
                Image.open(os.path.join(self.images_dir, 'original', name)).convert('RGB'))
            torch_cat_list.append(image_original)
        if 'eosin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_eosin = self.transform_eosin(
                Image.open(os.path.join(self.images_dir, 'eosin', name)).convert('RGB'))
            torch_cat_list.append(image_eosin)
        if 'hematoxylin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_hematoxylin = self.transform_hematoxylin(
                Image.open(os.path.join(self.images_dir, 'hematoxylin', name)).convert('RGB'))
            torch_cat_list.append(image_hematoxylin)

        torch_cat_list = img_augmentation(torch_cat_list, [256, 256])

        for i in range(len(torch_cat_list)):
            torch_cat_list[i] = torch_cat_list[i].unsqueeze(0)

        return torch.cat(torch_cat_list, dim=0), label, name

    def read_file(self, filename):
        images_label_list = []
        with open(filename, 'r') as f:
            lines = f.readlines()
            for line in lines:
                line = line.rstrip()
                name = line[:-2]
                label = line[-1]
                images_label_list.append([name, int(label)])
        return images_label_list


class GDC_Bladder_Tumor_Dataset_SupCon(Dataset):
    def __init__(self, images_dir, label_file_dir, modality_list):
        super(GDC_Bladder_Tumor_Dataset_SupCon, self).__init__()
        self.images_dir = images_dir
        self.modality_list = modality_list
        self.transform_original = get_transforms(mean=mean_dict['original'],
                                                 std=std_dict['original'],
                                                 resize_size=default_img_size,
                                                 random_crop_size=None)
        self.transform_eosin = get_transforms(mean_dict['eosin'],
                                              std_dict['eosin'],
                                              resize_size=default_img_size,
                                              random_crop_size=None)
        self.transform_hematoxylin = get_transforms(mean_dict['hematoxylin'],
                                                    std_dict['hematoxylin'],
                                                    resize_size=default_img_size,
                                                    random_crop_size=None)
        self.images_list = self.read_file(label_file_dir)

    def __len__(self):
        return len(self.images_list)

    def __getitem__(self, idx):
        name = self.images_list[idx][0]
        label = self.images_list[idx][1]

        seed = torch.random.seed()
        torch_cat_list = []
        if 'original' in self.modality_list:
            torch.random.manual_seed(seed)
            image_original = self.transform_original(
                Image.open(os.path.join(self.images_dir, 'original', name)).convert('RGB'))
            torch_cat_list.append(image_original)
        if 'eosin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_eosin = self.transform_eosin(
                Image.open(os.path.join(self.images_dir, 'eosin', name)).convert('RGB'))
            torch_cat_list.append(image_eosin)
        if 'hematoxylin' in self.modality_list:
            torch.random.manual_seed(seed)
            image_hematoxylin = self.transform_hematoxylin(
                Image.open(os.path.join(self.images_dir, 'hematoxylin', name)).convert('RGB'))
            torch_cat_list.append(image_hematoxylin)

        torch_cat_list_1 = img_augmentation(torch_cat_list, [256, 256])
        torch_cat_list_2 = img_augmentation(torch_cat_list, [256, 256])

        for i in range(len(torch_cat_list)):
            torch_cat_list_1[i] = torch_cat_list_1[i].unsqueeze(0)
            torch_cat_list_2[i] = torch_cat_list_2[i].unsqueeze(0)

        return [torch.cat(torch_cat_list_1, dim=0), torch.cat(torch_cat_list_2, dim=0)], label, name

    def read_file(self, filename):
        images_label_list = []
        with open(filename, 'r') as f:
            lines = f.readlines()
            for line in lines:
                line = line.rstrip()
                name = line[:-2]
                label = line[-1]
                images_label_list.append([name, int(label)])
        return images_label_list


def random_dict(dicts):
    dict_key_list = list(dicts.keys())
    random.shuffle(dict_key_list)
    new_dic = {}
    for key in dict_key_list:
        new_dic[key] = dicts.get(key)
    return new_dic
