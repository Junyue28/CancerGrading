import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from networks.Baseline_Model import Baseline3Modality2MLP
from networks.SE_ResNet import SELayer, generate_se_resnet_model
from networks.vanillanet import generate_vanillanet_model


class SelfAttention(nn.Module):

    def __init__(self, hidden_size, num_attention_heads, dropout_prob):
        super(SelfAttention, self).__init__()
        if hidden_size % num_attention_heads != 0:
            raise ValueError(
                "The hidden size (%d) is not a multiple of the number of attention "
                "heads (%d)" % (hidden_size, num_attention_heads))

        self.num_attention_heads = num_attention_heads
        self.attention_head_size = int(hidden_size / num_attention_heads)
        self.all_head_size = int(self.num_attention_heads * self.attention_head_size)

        self.query = nn.Linear(hidden_size, self.all_head_size)
        self.key = nn.Linear(hidden_size, self.all_head_size)
        self.value = nn.Linear(hidden_size, self.all_head_size)

        self.dropout = nn.Dropout(dropout_prob)

    def transpose_for_scores(self, x):
        new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)

    def forward(self, hidden_states):
        mixed_query_layer = self.query(hidden_states)
        mixed_key_layer = self.key(hidden_states)
        mixed_value_layer = self.value(hidden_states)

        query_layer = self.transpose_for_scores(mixed_query_layer)
        key_layer = self.transpose_for_scores(mixed_key_layer)
        value_layer = self.transpose_for_scores(mixed_value_layer)

        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        attention_scores = attention_scores / math.sqrt(self.attention_head_size)

        attention_probs = nn.Softmax(dim=-1)(attention_scores)

        attention_probs = self.dropout(attention_probs)

        context_layer = torch.matmul(attention_probs, value_layer)
        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_context_layer_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(*new_context_layer_shape)
        return context_layer


class conv_fusion(nn.Module):
    def __init__(self, num_channel):
        super(conv_fusion, self).__init__()
        self.conv_l1 = nn.Conv2d(num_channel, num_channel, kernel_size=3, stride=2, padding=1, bias=False)
        self.bn_l1 = nn.BatchNorm2d(num_channel)
        self.relu = nn.ReLU(inplace=True)
        self.conv_l2 = nn.Conv2d(num_channel, num_channel, kernel_size=3, stride=2, padding=1, bias=False)
        self.bn_l2 = nn.BatchNorm2d(num_channel)
        self.conv_l3 = nn.Conv2d(num_channel, num_channel, kernel_size=3, stride=2, padding=1, bias=False)
        self.bn_l3 = nn.BatchNorm2d(num_channel)

    def forward(self, x):
        out = self.conv_l1(x)
        out = self.bn_l1(out)
        out = self.relu(out)
        out = self.conv_l2(out)
        out = self.bn_l2(out)
        out = self.relu(out)
        out = self.conv_l3(out)
        out = self.bn_l3(out)
        out = self.relu(out)
        out = torch.squeeze(out)
        return out


class encoder_1modality_with_projection_head(nn.Module):
    def __init__(self, model_type='se_vanillanet', model_depth=4, projection_head_type='linear', out_feat=1000):
        super(encoder_1modality_with_projection_head, self).__init__()
        if 'se_vanillanet' == model_type:
            self.encoder = generate_vanillanet_model(model_depth=model_depth, need_classifier=False, need_se=True)
            if model_depth == 4:
                num_channel = 768
            else:
                num_channel = 4096
        elif 'se_resnet' == model_type:
            self.encoder = generate_se_resnet_model(model_depth=model_depth, need_classifier=False)
            if model_depth in [18, 34]:
                num_channel = 512
            else:
                num_channel = 2048
        else:
            raise Exception(f'Model type not supported: {model_type}')

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        if projection_head_type == 'linear':
            self.projection_head = nn.Linear(num_channel, out_feat)
        elif projection_head_type == 'mlp':
            self.projection_head = nn.Sequential(
                nn.Linear(num_channel, int(num_channel / 2)),
                nn.ReLU(inplace=True),
                nn.Linear(int(num_channel / 2), out_feat)
            )
        else:
            raise NotImplementedError(f'Projection head not supported: {projection_head_type}')

    def forward(self, x):
        out = self.encoder(x[:, 0, :, :, :])
        out = self.avgpool(out)
        out = torch.flatten(out, 1)
        out = self.projection_head(out)
        return F.normalize(out)


class decoder_SE_block(nn.Module):
    def __init__(self, num_channel):
        super(decoder_SE_block, self).__init__()
        self.decoder_l1 = SELayer(num_channel)
        self.decoder_l2 = SELayer(num_channel)
        self.decoder_l3 = SELayer(num_channel)

    def forward(self, x):
        out = self.decoder_l1(x)
        out = self.decoder_l2(out)
        out = self.decoder_l3(out)
        return out


class decoder_dual_branch(nn.Module):
    def __init__(self, num_channel, hidden_size):
        super(decoder_dual_branch, self).__init__()
        self.branch_1_1 = SelfAttention(hidden_size=hidden_size, num_attention_heads=4, dropout_prob=0.2)
        self.branch_1_2 = SelfAttention(hidden_size=hidden_size, num_attention_heads=4, dropout_prob=0.2)
        self.branch_2 = conv_fusion(num_channel=num_channel)

    def forward(self, x):
        branch_1_out = self.branch_1_1(torch.flatten(x, start_dim=2, end_dim=3))
        branch_1_out = self.branch_1_2(branch_1_out)
        branch_1_out = torch.mean(branch_1_out, dim=2)
        branch_1_out = torch.squeeze(branch_1_out)

        branch_2_out = self.branch_2(x)

        return torch.cat((branch_1_out, branch_2_out), dim=1)


class encoder(nn.Module):
    def __init__(self, model_type='se_vanillanet', model_depth=4, modality_num=3):
        super(encoder, self).__init__()
        self.modality_num = modality_num

        if 'se_vanillanet' == model_type:
            self.model_original = generate_vanillanet_model(model_depth=model_depth, need_classifier=False,
                                                            need_se=True)
            self.model_eosin = generate_vanillanet_model(model_depth=model_depth, need_classifier=False,
                                                         need_se=True)
            if self.modality_num == 3:
                self.model_hematoxylin = generate_vanillanet_model(model_depth=model_depth, need_classifier=False,
                                                                   need_se=True)
        elif 'se_resnet' == model_type:
            self.model_original = generate_se_resnet_model(model_depth=model_depth, need_classifier=False)
            self.model_eosin = generate_se_resnet_model(model_depth=model_depth, need_classifier=False)
            if self.modality_num == 3:
                self.model_hematoxylin = generate_se_resnet_model(model_depth=model_depth, need_classifier=False)
        else:
            raise Exception(f'Model type not supported: {model_type}')

    def forward(self, x):
        out_original = self.model_original(x[:, 0, :, :, :])
        out_eosin = self.model_eosin(x[:, 1, :, :, :])
        if self.modality_num == 3:
            out_hematoxylin = self.model_hematoxylin(x[:, 2, :, :, :])
            out = torch.cat([out_original, out_eosin, out_hematoxylin], dim=1)
        else:
            out = torch.cat([out_original, out_eosin], dim=1)
        return out


class encoder_3modality_with_projection_head(nn.Module):
    def __init__(self, model_type='se_vanillanet', model_depth=4, projection_head_type='linear', out_feat=1000):
        super(encoder_3modality_with_projection_head, self).__init__()
        self.encoder = encoder(model_type=model_type, model_depth=model_depth)
        if 'se_vanillanet' == model_type:
            if model_depth == 4:
                num_channel = 768 * 3
            else:
                num_channel = 4096 * 3
        elif 'se_resnet' == model_type:
            if model_depth in [18, 34]:
                num_channel = 512 * 3
            else:
                num_channel = 2048 * 3
        else:
            raise Exception(f'Model type not supported: {model_type}')

        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        if projection_head_type == 'linear':
            self.projection_head = nn.Linear(num_channel, out_feat)
        elif projection_head_type == 'mlp':
            self.projection_head = nn.Sequential(
                nn.Linear(num_channel, num_channel),
                nn.ReLU(inplace=True),
                nn.Linear(num_channel, out_feat)
            )
        else:
            raise NotImplementedError(f'Projection head not supported: {projection_head_type}')

    def forward(self, x):
        out = self.encoder(x)
        out = self.avgpool(out)
        out = torch.flatten(out, 1)
        out = self.projection_head(out)

        return F.normalize(out)


class McacNet(nn.Module):
    def __init__(self, model_type='se_vanillanet', model_depth=4, classifiy_head_type='linear', num_classes=2, modality_num=3):
        super(McacNet, self).__init__()
        self.encoder = encoder(model_type=model_type, model_depth=model_depth, modality_num=modality_num)
        self.modality_num = modality_num
        self.encoder_output_channel = 768
        if 'se_vanillanet' == model_type:
            if model_depth == 4:
                self.encoder_output_channel = 768
            else:
                self.encoder_output_channel = 4096
        elif 'se_resnet' == model_type:
            if model_depth in [18, 34]:
                self.encoder_output_channel = 512
            else:
                self.encoder_output_channel = 2048
        else:
            raise Exception(f'Model type not supported: {model_type}')
        self.num_channel = self.encoder_output_channel * self.modality_num

        self.decoder = decoder_dual_branch(num_channel=self.num_channel, hidden_size=64)

        self.decoder_out_feature_num = self.num_channel * 2

        if classifiy_head_type == 'linear':
            self.classifiy_head = nn.Linear(self.decoder_out_feature_num, num_classes)
        elif classifiy_head_type == 'mlp':
            self.classifiy_head = nn.Sequential(
                nn.Linear(self.decoder_out_feature_num, int(self.decoder_out_feature_num/2)),
                nn.ReLU(inplace=True),
                nn.Linear(int(self.decoder_out_feature_num/2), num_classes)
            )
        else:
            raise NotImplementedError(f'Projection head not supported: {classifiy_head_type}')

    def forward(self, x):

        out = self.encoder(x)
        out = self.decoder(out)
        out = self.classifiy_head(out)

        return out
