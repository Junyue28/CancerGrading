import torch
import torch.nn as nn
from networks.Backbone import generate_model


class Baseline1Modality(nn.Module):
    def __init__(self, model_name='resnet', model_depth=50, num_classes=2):
        super(Baseline1Modality, self).__init__()
        self.model = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=True,
                                    num_classes=num_classes)

    def forward(self, x):
        return self.model(x[:, 0, :, :, :])


class Baseline2Modality2MLP(nn.Module):
    def __init__(self, model_name='resnet', model_depth=50, num_classes=2):
        super(Baseline2Modality2MLP, self).__init__()
        self.model_name = model_name
        self.model_A = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=False,
                                      num_classes=num_classes)
        self.model_B = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=False,
                                      num_classes=num_classes)

        channel_in = None
        if 'resnet' == model_name or 'se_resnet' == model_name:
            channel_in = 512
            if model_depth in [50, 101, 152]:
                channel_in = 2048
            self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        elif 'efficientnet' == model_name:
            channel_in = self.model_A._fc.in_features

            self.model_A._fc = nn.Identity()
            self.model_B._fc = nn.Identity()

            # channel_in = self.model_A.classifier[1].in_features

            # self.model_A.classifier = nn.Identity()
            # self.model_B.classifier = nn.Identity()

        elif 'vanillanet' == model_name or 'se_vanillanet' == model_name:
            channel_in = 4096
            if 4 == model_depth:
                channel_in = 768
            self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        channel_in_half = int(channel_in / 2)

        self.mlp1 = nn.Sequential(
            nn.Linear(channel_in * 2, channel_in * 1),
            nn.ReLU(inplace=True),
            nn.Linear(channel_in * 1, channel_in)
        )
        self.mlp2 = nn.Sequential(
            nn.Linear(channel_in, channel_in_half),
            nn.ReLU(inplace=True),
            nn.Linear(channel_in_half, num_classes)
        )

    def forward(self, x):
        if self.model_name in ['efficientnet']:
            return self.mlp2(self.mlp1(torch.cat((self.model_A(x[:, 0, :, :, :]),
                                                  self.model_B(x[:, 1, :, :, :])), dim=1)))
        elif self.model_name in ['resnet', 'se_resnet', 'vanillanet', 'se_vanillanet']:
            out_a = torch.flatten(self.avgpool(self.model_A(x[:, 0, :, :, :])), 1)
            out_b = torch.flatten(self.avgpool(self.model_B(x[:, 1, :, :, :])), 1)
            return self.mlp2(self.mlp1(torch.cat((out_a, out_b), dim=1)))


class Baseline3Modality2MLP(nn.Module):
    def __init__(self, model_name='resnet', model_depth=50, num_classes=2):
        super(Baseline3Modality2MLP, self).__init__()
        self.model_name = model_name
        self.model_A = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=False,
                                      num_classes=num_classes)
        self.model_B = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=False,
                                      num_classes=num_classes)
        self.model_C = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=False,
                                      num_classes=num_classes)

        channel_in = None
        if 'resnet' == model_name or 'se_resnet' == model_name:
            channel_in = 512
            if model_depth in [50, 101, 152]:
                channel_in = 2048
            self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        elif 'efficientnet' == model_name:
            channel_in = self.model_A._fc.in_features

            self.model_A._fc = nn.Identity()
            self.model_B._fc = nn.Identity()
            self.model_C._fc = nn.Identity()

            # channel_in = self.model_A.classifier[1].in_features

            # self.model_A.classifier = nn.Identity()
            # self.model_B.classifier = nn.Identity()
            # self.model_C.classifier = nn.Identity()

        elif 'vanillanet' == model_name or 'se_vanillanet' == model_name:
            channel_in = 4096
            if 4 == model_depth:
                channel_in = 768
            self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        channel_in_half = int(channel_in / 2)

        self.mlp1 = nn.Sequential(
            nn.Linear(channel_in * 3, channel_in * 2),
            nn.ReLU(inplace=True),
            nn.Linear(channel_in * 2, channel_in)
        )
        self.mlp2 = nn.Sequential(
            nn.Linear(channel_in, channel_in_half),
            nn.ReLU(inplace=True),
            nn.Linear(channel_in_half, num_classes)
        )

    def forward(self, x):
        if self.model_name in ['efficientnet']:
            return self.mlp2(self.mlp1(torch.cat((self.model_A(x[:, 0, :, :, :]),
                                                  self.model_B(x[:, 1, :, :, :]),
                                                  self.model_C(x[:, 2, :, :, :])), dim=1)))
        elif self.model_name in ['resnet', 'se_resnet', 'vanillanet', 'se_vanillanet']:
            out_a = torch.flatten(self.avgpool(self.model_A(x[:, 0, :, :, :])), 1)
            out_b = torch.flatten(self.avgpool(self.model_B(x[:, 1, :, :, :])), 1)
            out_c = torch.flatten(self.avgpool(self.model_C(x[:, 2, :, :, :])), 1)
            return self.mlp2(self.mlp1(torch.cat((out_a, out_b, out_c), dim=1)))


class Baseline4Modality2MLP(nn.Module):
    def __init__(self, model_name='resnet', model_depth=50, num_classes=2):
        super(Baseline4Modality2MLP, self).__init__()
        self.model_name = model_name
        self.model_A = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=False,
                                      num_classes=num_classes)
        self.model_B = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=False,
                                      num_classes=num_classes)
        self.model_C = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=False,
                                      num_classes=num_classes)
        self.model_D = generate_model(model_name=model_name, model_depth=model_depth, need_classifier=False,
                                      num_classes=num_classes)

        channel_in = None
        if 'resnet' == model_name or 'se_resnet' == model_name:
            channel_in = 512
            if model_depth in [50, 101, 152]:
                channel_in = 2048
            self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        elif 'efficientnet' == model_name:
            channel_in = self.model_A._fc.in_features
            self.model_A._fc = nn.Identity()
            self.model_B._fc = nn.Identity()
            self.model_C._fc = nn.Identity()
            self.model_D._fc = nn.Identity()

            # channel_in = self.model_A.classifier[1].in_features
            # self.model_A.classifier = nn.Identity()
            # self.model_B.classifier = nn.Identity()
            # self.model_C.classifier = nn.Identity()
            # self.model_D.classifier = nn.Identity()

        elif 'vanillanet' == model_name or 'se_vanillanet' == model_name:
            channel_in = 4096
            if 4 == model_depth:
                channel_in = 768
            self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

        channel_in_half = int(channel_in / 2)

        self.mlp1 = nn.Sequential(
            nn.Linear(channel_in * 4, channel_in * 2),
            nn.ReLU(inplace=True),
            nn.Linear(channel_in * 2, channel_in)
        )
        self.mlp2 = nn.Sequential(
            nn.Linear(channel_in, channel_in_half),
            nn.ReLU(inplace=True),
            nn.Linear(channel_in_half, num_classes)
        )

    def forward(self, x):
        if self.model_name in ['efficientnet']:
            return self.mlp2(self.mlp1(torch.cat((self.model_A(x[:, 0, :, :, :]),
                                                  self.model_B(x[:, 1, :, :, :]),
                                                  self.model_C(x[:, 2, :, :, :]),
                                                  self.model_D(x[:, 3, :, :, :])), dim=1)))
        elif self.model_name in ['resnet', 'se_resnet', 'vanillanet', 'se_vanillanet']:
            out_a = torch.flatten(self.avgpool(self.model_A(x[:, 0, :, :, :])), 1)
            out_b = torch.flatten(self.avgpool(self.model_B(x[:, 1, :, :, :])), 1)
            out_c = torch.flatten(self.avgpool(self.model_C(x[:, 2, :, :, :])), 1)
            out_d = torch.flatten(self.avgpool(self.model_D(x[:, 3, :, :, :])), 1)
            return self.mlp2(self.mlp1(torch.cat((out_a, out_b, out_c, out_d), dim=1)))
