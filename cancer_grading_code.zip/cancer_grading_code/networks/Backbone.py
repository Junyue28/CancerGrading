from efficientnet_pytorch import EfficientNet

from networks.Custom3 import generate_Custom3_model
from networks.FSConv import generate_FSConv_model
from networks.SE_ResNet import generate_se_resnet_model
from networks.resnet import generate_resnet_model
from networks.vanillanet import generate_vanillanet_model


def generate_model(model_name='resnet', model_depth=50, num_classes=2, need_classifier=True):
    assert model_name in ['resnet', 'efficientnet', 'se_resnet', 'vanillanet', 'se_vanillanet', 'FSConv', 'Custom3']
    model = None
    if model_name == 'resnet':
        assert model_depth in [18, 34, 50, 101, 152]
        model = generate_resnet_model(model_depth=model_depth, need_classifier=need_classifier,
                                      num_classes=num_classes)
    elif model_name == 'se_resnet':
        assert model_depth in [18, 34, 50, 101, 152]
        model = generate_se_resnet_model(model_depth=model_depth, need_classifier=need_classifier,
                                         num_classes=num_classes)
    elif model_name == 'efficientnet':
        assert model_depth in [0, 1, 2, 3, 4]
        if model_depth == 0:
            model = EfficientNet.from_name('efficientnet-b0', num_classes=num_classes)
            # model = models.efficientnet_b0(num_classes=num_classes)
        elif model_depth == 1:
            model = EfficientNet.from_name('efficientnet-b1', num_classes=num_classes)
            # model = models.efficientnet_b1(num_classes=num_classes)
        elif model_depth == 2:
            model = EfficientNet.from_name('efficientnet-b2', num_classes=num_classes)
            # model = models.efficientnet_b2(num_classes=num_classes)
        elif model_depth == 3:
            model = EfficientNet.from_name('efficientnet-b3', num_classes=num_classes)
            # model = models.efficientnet_b3(num_classes=num_classes)
        elif model_depth == 4:
            model = EfficientNet.from_name('efficientnet-b4', num_classes=num_classes)
            # model = models.efficientnet_b4(num_classes=num_classes)
    elif model_name == 'vanillanet':
        assert model_depth in [4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
        model = generate_vanillanet_model(model_depth=model_depth, need_classifier=need_classifier,
                                          num_classes=num_classes)
    elif model_name == 'se_vanillanet':
        assert model_depth in [4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
        model = generate_vanillanet_model(model_depth=model_depth, need_classifier=need_classifier,
                                          num_classes=num_classes, need_se=True)
    elif model_name == 'FSConv':
        model = generate_FSConv_model(num_classes=num_classes)
    elif model_name == 'Custom3':
        model = generate_Custom3_model(num_classes=num_classes)

    return model
