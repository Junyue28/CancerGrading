import torch
import torch.nn as nn


class Custom3(nn.Module):
    def __init__(self, num_classes=2):
        super(Custom3, self).__init__()
        self.conv1 = nn.Conv2d(3, 32, kernel_size=3, stride=1, padding=1)
        self.bn1 = nn.BatchNorm2d(32)
        self.relu1 = nn.ReLU(inplace=True)
        self.max_pool1 = nn.MaxPool2d(2)

        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
        self.bn2 = nn.BatchNorm2d(64)
        self.relu2 = nn.ReLU(inplace=True)
        self.max_pool2 = nn.MaxPool2d(2)

        self.conv3 = nn.Conv2d(64, 96, kernel_size=3, stride=1, padding=1)
        self.bn3 = nn.BatchNorm2d(96)
        self.relu3 = nn.ReLU(inplace=True)
        self.max_pool3 = nn.MaxPool2d(2)

        self.conv4 = nn.Conv2d(96, 128, kernel_size=3, stride=1, padding=1)
        self.bn4 = nn.BatchNorm2d(128)
        self.relu4 = nn.ReLU(inplace=True)
        self.max_pool4 = nn.MaxPool2d(2)

        self.conv5 = nn.Conv2d(128, 160, kernel_size=3, stride=1, padding=1)
        self.bn5 = nn.BatchNorm2d(160)
        self.relu5 = nn.ReLU(inplace=True)
        self.max_pool5 = nn.MaxPool2d(2)

        self.conv6 = nn.Conv2d(160, 192, kernel_size=3, stride=1, padding=1)
        self.bn6 = nn.BatchNorm2d(192)
        self.relu6 = nn.ReLU(inplace=True)
        self.max_pool6 = nn.MaxPool2d(2)

        self.conv7 = nn.Conv2d(192, 224, kernel_size=3, stride=1, padding=1)
        self.bn7 = nn.BatchNorm2d(224)
        self.relu7 = nn.ReLU(inplace=True)
        self.max_pool7 = nn.MaxPool2d(2)

        self.conv8 = nn.Conv2d(224, 256, kernel_size=3, stride=1, padding=1)
        self.bn8 = nn.BatchNorm2d(256)
        self.relu8 = nn.ReLU(inplace=True)
        self.max_pool8 = nn.MaxPool2d(2)

        # 512
        self.fc1 = nn.Linear(1024, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, num_classes)

        # 256
        # self.fc1 = nn.Linear(256, 128)
        # self.fc2 = nn.Linear(128, 64)
        # self.fc3 = nn.Linear(64, num_classes)

    def forward(self, x):
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu1(out)
        out = self.max_pool1(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu2(out)
        out = self.max_pool2(out)

        out = self.conv3(out)
        out = self.bn3(out)
        out = self.relu3(out)
        out = self.max_pool3(out)

        out = self.conv4(out)
        out = self.bn4(out)
        out = self.relu4(out)
        out = self.max_pool4(out)

        out = self.conv5(out)
        out = self.bn5(out)
        out = self.relu5(out)
        out = self.max_pool5(out)

        out = self.conv6(out)
        out = self.bn6(out)
        out = self.relu6(out)
        out = self.max_pool6(out)

        out = self.conv7(out)
        out = self.bn7(out)
        out = self.relu7(out)
        out = self.max_pool7(out)

        out = self.conv8(out)
        out = self.bn8(out)
        out = self.relu8(out)
        out = self.max_pool8(out)

        out = torch.flatten(out, 1)
        out = self.fc1(out)
        out = self.fc2(out)
        out = self.fc3(out)

        return out


def generate_Custom3_model(**kwargs):
    model = Custom3(**kwargs)
    return model
