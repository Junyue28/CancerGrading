import torch
import torch.nn as nn


class FSConv(nn.Module):
    def __init__(self, num_classes=2):
        super(FSConv, self).__init__()
        self.conv1 = nn.Conv2d(3, 32, kernel_size=3, stride=1, padding=1)
        self.relu1 = nn.ReLU(inplace=True)
        self.max_pool1 = nn.MaxPool2d(2)

        self.conv2 = nn.Conv2d(32, 124, kernel_size=3, stride=1, padding=1)
        self.relu2 = nn.ReLU(inplace=True)
        self.max_pool2 = nn.MaxPool2d(2)

        self.conv3 = nn.Conv2d(124, 512, kernel_size=3, stride=1, padding=1)
        self.relu3 = nn.ReLU(inplace=True)
        self.max_pool3 = nn.MaxPool2d(2)

        self.max_pool = nn.MaxPool2d(28)

        # 256
        self.fc = nn.Linear(512, num_classes)

        # 512
        # self.fc = nn.Linear(2048, num_classes)

    def forward(self, x):
        out = self.conv1(x)
        out = self.relu1(out)
        out = self.max_pool1(out)

        out = self.conv2(out)
        out = self.relu2(out)
        out = self.max_pool2(out)

        out = self.conv3(out)
        out = self.relu3(out)
        out = self.max_pool3(out)

        out = self.max_pool(out)
        out = torch.flatten(out, 1)
        out = self.fc(out)

        return out


def generate_FSConv_model(**kwargs):
    model = FSConv(**kwargs)
    return model
