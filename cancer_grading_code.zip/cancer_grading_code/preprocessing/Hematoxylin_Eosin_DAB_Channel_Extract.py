from PIL import Image
from histolab.filters.image_filters import HematoxylinChannel, EosinChannel, DABChannel
import os
from tqdm import tqdm


def histolab_filters_Hematoxylin_Eosin_Channel_extract(data_path, save_path):
    eosin_channel = EosinChannel()
    hematoxylin_channel = HematoxylinChannel()
    # basename = os.path.basename(data_path)
    eosin_channel_save_path = os.path.join(save_path, r'eosin')
    hematoxylin_channel_save_path = os.path.join(save_path, r'hematoxylin')
    if not os.path.exists(eosin_channel_save_path):
        os.mkdir(eosin_channel_save_path)
    if not os.path.exists(hematoxylin_channel_save_path):
        os.mkdir(hematoxylin_channel_save_path)

    for img_name in tqdm(os.listdir(data_path)):
        image_rgb = Image.open(os.path.join(data_path, img_name))
        image_e = eosin_channel(image_rgb)
        image_e.save(os.path.join(eosin_channel_save_path, img_name))
        image_h = hematoxylin_channel(image_rgb)
        image_h.save(os.path.join(hematoxylin_channel_save_path, img_name))


def read_txt_file(filename):
    file_list = []
    with open(filename, 'r') as f:
        lines = f.readlines()
        for line in lines:
            line = line.rstrip()
            file_list.append(line)
    return file_list


def histolab_filters_Hematoxylin_Eosin_DAB_Channel_extract(data_path, save_path, div_file_path=None):
    eosin_channel = EosinChannel()
    hematoxylin_channel = HematoxylinChannel()
    DAB_channel = DABChannel()

    # basename = os.path.basename(data_path)
    eosin_channel_save_path = os.path.join(save_path, r'eosin')
    hematoxylin_channel_save_path = os.path.join(save_path, r'hematoxylin')
    DAB_channel_save_path = os.path.join(save_path, r'DAB')
    if not os.path.exists(eosin_channel_save_path):
        os.makedirs(eosin_channel_save_path)
    if not os.path.exists(hematoxylin_channel_save_path):
        os.makedirs(hematoxylin_channel_save_path)
    if not os.path.exists(DAB_channel_save_path):
        os.makedirs(DAB_channel_save_path)

    if div_file_path is not None:
        case_list = read_txt_file(div_file_path)
    else:
        case_list = os.listdir(data_path)

    for case_name in tqdm(case_list):
        case_path = os.path.join(data_path, case_name, 'images')
        for img_name in os.listdir(case_path):
            try:
                image_rgb = Image.open(os.path.join(case_path, img_name))

                image_e = eosin_channel(image_rgb)
                eosin_case_path = os.path.join(eosin_channel_save_path, case_name, 'images')
                if not os.path.exists(eosin_case_path):
                    os.makedirs(eosin_case_path)
                image_e.save(os.path.join(eosin_case_path, img_name))

                image_h = hematoxylin_channel(image_rgb)
                hematoxylin_case_path = os.path.join(hematoxylin_channel_save_path, case_name, 'images')
                if not os.path.exists(hematoxylin_case_path):
                    os.makedirs(hematoxylin_case_path)
                image_h.save(os.path.join(hematoxylin_case_path, img_name))

                image_DAB = DAB_channel(image_rgb)
                DAB_case_path = os.path.join(DAB_channel_save_path, case_name, 'images')
                if not os.path.exists(DAB_case_path):
                    os.makedirs(DAB_case_path)
                image_DAB.save(os.path.join(DAB_case_path, img_name))
            except Exception as e:
                print(img_name)
            finally:
                pass
