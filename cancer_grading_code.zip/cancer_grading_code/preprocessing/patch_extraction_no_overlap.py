import os
import numpy as np
import openslide
import pandas as pd
from tqdm import tqdm
from histolab.filters.image_filters import (
    ApplyMaskImage,
    Compose,
    OtsuThreshold,
    RgbToGrayscale,
)
from histolab.filters.morphological_filters import BinaryDilation, RemoveSmallHoles, RemoveSmallObjects
from PIL import Image

Image.MAX_IMAGE_PIXELS = None

pen_marked_images = []

def composed_filters(image_rgb):
    filters = Compose(
        [
            RgbToGrayscale(),
            OtsuThreshold(),
            BinaryDilation(),
            RemoveSmallHoles(),
            RemoveSmallObjects(),
            # ApplyMaskImage(image_rgb),
        ]
    )
    return filters(image_rgb)


def patch_extraction(BASE_PATH, BASE_SAVE_PATH, wsi_name, wsi_level, patch_size,
                     patch_classification_method, patch_classification_threshold):

    data_dir = BASE_PATH + r'\train_images'
    mask_dir = BASE_PATH + r'\train_label_masks'

    slide_path = os.path.join(data_dir, f'{wsi_name}.tiff')
    mask_path = os.path.join(mask_dir, f'{wsi_name}_mask.tiff')

    patch_save_path = os.path.join(BASE_SAVE_PATH, str(patch_size[0]) + '_' + str(patch_size[1]), wsi_name, 'images')
    if not os.path.exists(patch_save_path):
        os.makedirs(patch_save_path)

    mask_save_path = os.path.join(BASE_SAVE_PATH, str(patch_size[0]) + '_' + str(patch_size[1]), wsi_name, 'masks')
    if not os.path.exists(mask_save_path):
        os.makedirs(mask_save_path)


    slide = openslide.open_slide(slide_path)
    mask = np.array(openslide.open_slide(mask_path).read_region((0, 0), wsi_level, slide.level_dimensions[0]))[:, :, 0]

    rgb_image_np = np.array(slide.read_region((0, 0), wsi_level, slide.level_dimensions[0]))[:, :, 0:-1]
    rgb_image_np[np.where(mask == 0)] = [255, 255, 255]
    rgb_image_PIL = Image.fromarray(np.uint8(rgb_image_np))
    del rgb_image_np
    resulting_mask = composed_filters(rgb_image_PIL)
    mask[np.where(resulting_mask == False)] = 0

    new_mask_save_path = os.path.join(BASE_SAVE_PATH, 'new_label_mask')
    if not os.path.exists(new_mask_save_path):
        os.makedirs(new_mask_save_path)
    Image.fromarray(mask).save(os.path.join(new_mask_save_path, wsi_name + '_mask.png'))

    slide_size = slide.level_dimensions[0]
    slide_x_div = slide_size[0] // patch_size[0]
    slide_y_div = slide_size[1] // patch_size[1]
    threshold_pixel = patch_classification_threshold * patch_size[0] * patch_size[1]

    for x in range(0, slide_x_div):
        for y in range(0, slide_y_div):
            image_patch = slide.read_region((x * patch_size[0], y * patch_size[1]), wsi_level, patch_size)
            mask_patch = mask[y * patch_size[1]:y * patch_size[1] + patch_size[1], x * patch_size[0]:x * patch_size[0] + patch_size[0]]
            unique, count = np.unique(mask_patch, return_counts=True)
            data_count = dict(zip(unique, count))
            temp_class = 0
            if patch_classification_method == 1:
                temp_max_pixel_num = 0
                for key_class_name, value_pixel_num in data_count.items():
                    if value_pixel_num >= temp_max_pixel_num:
                        temp_class = int(key_class_name)
                        temp_max_pixel_num = value_pixel_num
            elif patch_classification_method == 2:
                for key_class_name, value_pixel_num in data_count.items():
                    if value_pixel_num >= threshold_pixel:
                        temp_class = int(key_class_name)
            elif patch_classification_method == 3:
                for key_class_name, value_pixel_num in data_count.items():
                    if key_class_name == 0 or key_class_name == '0':
                        if value_pixel_num >= threshold_pixel:
                            temp_class = 0
                            continue
                    elif int(key_class_name) > temp_class:
                        temp_class = int(key_class_name)
            elif patch_classification_method == 4:
                for key_class_name, value_pixel_num in data_count.items():
                    if int(key_class_name) > temp_class and value_pixel_num >= threshold_pixel:
                        temp_class = int(key_class_name)
            else:
                raise Exception('"patch_classification_method" parameter setting error. This method does not exist!')

            if temp_class == 0 or temp_class == '0':
                continue
            image_name = f'{wsi_name}_{x * patch_size[0]}_{y * patch_size[1]}_{temp_class}'
            image_patch.save(os.path.join(patch_save_path, image_name + '.png'))
            np.save(os.path.join(mask_save_path, image_name + '.npy'), mask_patch)


if __name__ == '__main__':
    BASE_PATH = r''

    BASE_SAVE_PATH = r''
    wsi_level = 0
    patch_size = (256, 256)

    patch_classification_method = 4
    patch_classification_threshold = 0.1

    train_pd = pd.read_csv(BASE_PATH + r'\train.csv').set_index('image_id')

    train_radboud_list = train_pd[train_pd['data_provider'] == 'radboud'].index.values.tolist()

    train_images_name_list = os.listdir(BASE_PATH + r'\train_images')
    train_masks_name_list = os.listdir(BASE_PATH + r'\train_label_masks')

    miss_image_list = []
    miss_mask_list = []
    for wsi_name in tqdm(train_radboud_list):
        no_processing_flag = False
        if (wsi_name + '.tiff') not in train_images_name_list:
            miss_image_list.append(wsi_name)
            no_processing_flag = True
        if (wsi_name + '_mask.tiff') not in train_masks_name_list:
            miss_mask_list.append(wsi_name)
            no_processing_flag = True

        if os.path.exists(os.path.join(BASE_SAVE_PATH,
                                       str(patch_size[0]) + '_' + str(patch_size[1]),
                                       wsi_name)):
            print(f'Path exists: {wsi_name}')
            no_processing_flag = True
        if wsi_name in pen_marked_images:
            print(f'Pen marked image: {wsi_name}')
            no_processing_flag = True
        if no_processing_flag:
            continue

        print(f'Start: {wsi_name}')
        patch_extraction(BASE_PATH, BASE_SAVE_PATH, wsi_name, wsi_level, patch_size, patch_classification_method,
                         patch_classification_threshold)
        print(f'End: {wsi_name}')

    miss_image_df = pd.DataFrame(miss_image_list, columns=['miss_image'])
    miss_mask_df = pd.DataFrame(miss_mask_list, columns=['miss_mask'])
    miss_image_df.to_excel(os.path.join(BASE_SAVE_PATH, 'miss_image.xlsx'), index=False)
    miss_mask_df.to_excel(os.path.join(BASE_SAVE_PATH, 'miss_mask.xlsx'), index=False)
