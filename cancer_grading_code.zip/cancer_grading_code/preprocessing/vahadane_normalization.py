import os

import numpy as np
from tiatoolbox import data
from tiatoolbox.tools import stainnorm
import cv2
import matplotlib.pyplot as plt
from tqdm import tqdm
from tiatoolbox.utils.misc import imread
import staintools
from PIL import Image
from PIL import ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True
Image.MAX_IMAGE_PIXELS = None


def vahadane_normalization_tiatoolbox_batch(sourceImagePath, resultImagePath):
    # target_image = data.stainnorm_target()
    target_image = imread('./tiatoolbox_target_image.png')

    # tiatoolbox Vahadane method
    stain_normalizer = stainnorm.VahadaneNormalizer()
    stain_normalizer.fit(target_image)

    for name in tqdm(os.listdir(sourceImagePath)):
        source_image = cv2.imread(os.path.join(sourceImagePath, name))
        source_image = source_image[:, :, [2, 1, 0]]
        normed_image = stain_normalizer.transform(source_image.copy())
        cv2.imwrite(os.path.join(resultImagePath, name), normed_image[:, :, [2, 1, 0]], [cv2.IMWRITE_PNG_COMPRESSION, 0])


def vahadane_normalization_tiatoolbox_show_single(img_path):
    # target_image = data.stainnorm_target()
    target_image = imread('./tiatoolbox_target_image.png')

    # tiatoolbox Vahadane method
    stain_normalizer = stainnorm.VahadaneNormalizer()
    stain_normalizer.fit(target_image)

    source_image = imread(img_path)
    normed_image = stain_normalizer.transform(source_image.copy())
    img = Image.fromarray(normed_image)
    img.show()


def vahadane_normalization_staintools_small_batch(sourceImagePath, resultImagePath, error_file):
    target = staintools.read_image("./tiatoolbox_target_image.png")
    # Standardize brightness (optional, can improve the tissue mask calculation)
    target = staintools.LuminosityStandardizer.standardize(target)
    normalizer = staintools.StainNormalizer(method='vahadane')
    normalizer.fit(target)

    print('Process folder: ' + sourceImagePath)
    error_files_list = []

    images = []
    imagesName = []
    source_files_list = os.listdir(sourceImagePath)
    if not os.path.exists(resultImagePath):
        os.makedirs(resultImagePath)
    result_files_list = os.listdir(resultImagePath)
    print('Read image and standardize brightness')
    for name in tqdm(source_files_list):
        to_transform = staintools.read_image(os.path.join(sourceImagePath, name))
        # Standardize brightness (optional, can improve the tissue mask calculation)
        to_transform = staintools.LuminosityStandardizer.standardize(to_transform)
        images.append(to_transform)
        imagesName.append(name)

    print('Stain normalize and save image')
    for i, v in enumerate(tqdm(images)):
        if imagesName[i] in result_files_list:
            continue
        try:
            transformed = normalizer.transform(v)
            Image.fromarray(transformed).save(os.path.join(resultImagePath, imagesName[i]))
        except Exception as e:
            error_files_list.append(imagesName[i])
            print(imagesName[i])
        finally:
            pass

    with open(error_file, 'w') as f:
        for filename in error_files_list:
            f.write(filename + '\n')


def vahadane_normalization_staintools_small_batch_cat(sourceImagePath, resultImagePath, error_file):
    target = staintools.read_image("./tiatoolbox_target_image.png")
    # Standardize brightness (optional, can improve the tissue mask calculation)
    target = staintools.LuminosityStandardizer.standardize(target)
    normalizer = staintools.StainNormalizer(method='vahadane')
    normalizer.fit(target)

    print('Process folder: ' + sourceImagePath)
    error_files_list = []

    source_files_list = os.listdir(sourceImagePath)
    if not os.path.exists(resultImagePath):
        os.makedirs(resultImagePath)
    result_files_list = os.listdir(resultImagePath)

    cat_step = 20
    div = len(source_files_list) // cat_step
    mod = len(source_files_list) % cat_step
    if mod > 0:
        div = div + 1

    for cat_num in range(div):
        images = []
        imagesName = []
        if cat_num + 1 != div:
            begin_n = cat_num * cat_step
            temp_source_files_list = source_files_list[begin_n:begin_n+20]
        else:
            begin_n = cat_num * cat_step
            temp_source_files_list = source_files_list[begin_n:]

        for name in temp_source_files_list:
            img = staintools.read_image(os.path.join(sourceImagePath, name))
            images.append(img)
            imagesName.append(name)
        to_transform = np.concatenate(images, axis=1)

        # Standardize brightness (optional, can improve the tissue mask calculation)
        to_transform = staintools.LuminosityStandardizer.standardize(to_transform)

        try:
            transformed = normalizer.transform(to_transform)
        except Exception as e:
            print(imagesName)
        finally:
            pass

        for idx, name in enumerate(imagesName):
            Image.fromarray(transformed[:, (idx * 256):(idx * 256) + 256, :]).save(os.path.join(resultImagePath, name))

    # with open(error_file, 'w') as f:
    #     for filename in error_files_list:
    #         f.write(filename + '\n')


def vahadane_normalization_staintools_large_batch(sourceImagePath, resultImagePath, error_file):
    target = staintools.read_image("./tiatoolbox_target_image.png")
    # Standardize brightness (optional, can improve the tissue mask calculation)
    target = staintools.LuminosityStandardizer.standardize(target)
    normalizer = staintools.StainNormalizer(method='vahadane')
    normalizer.fit(target)

    print('Process folder: ' + sourceImagePath)
    error_files_list = []

    source_files_list = os.listdir(sourceImagePath)
    result_files_list = os.listdir(resultImagePath)

    for name in tqdm(source_files_list):

        if name in result_files_list:
            continue

        to_transform = staintools.read_image(os.path.join(sourceImagePath, name))
        # Standardize brightness (optional, can improve the tissue mask calculation)
        to_transform = staintools.LuminosityStandardizer.standardize(to_transform)

        try:
            transformed = normalizer.transform(to_transform)
            Image.fromarray(transformed).save(os.path.join(resultImagePath, name))
        except Exception as e:
            error_files_list.append(name)
            print(name)
        finally:
            pass

    with open(error_file, 'w') as f:
        for filename in error_files_list:
            f.write(filename + '\n')


def vahadane_normalization_staintools_show_single(img_path):
    target = staintools.read_image("./tiatoolbox_target_image.png")
    to_transform = staintools.read_image(img_path)
    # Standardize brightness (optional, can improve the tissue mask calculation)
    target = staintools.LuminosityStandardizer.standardize(target)
    to_transform = staintools.LuminosityStandardizer.standardize(to_transform)
    normalizer = staintools.StainNormalizer(method='vahadane')
    normalizer.fit(target)
    transformed = normalizer.transform(to_transform)
    img = Image.fromarray(transformed)
    img.show()


def read_txt_file(filename):
    file_list = []
    with open(filename, 'r') as f:
        lines = f.readlines()
        for line in lines:
            line = line.rstrip()
            file_list.append(line)
    return file_list
