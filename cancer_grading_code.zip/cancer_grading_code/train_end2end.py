import os
import sys
import argparse
import time
import math

import pandas as pd
import tensorboard_logger as tb_logger
import torch
import torch.backends.cudnn as cudnn
from torch.utils.data import DataLoader

from datasets_loader.ARVANITI_dataset import ARVANITI_Dataset
from datasets_loader.BladderTumor_dataset import BladderTumorDataset
from datasets_loader.BreakHis_dataset import BreakHisDataset
from datasets_loader.GDC_Bladder_Tumor_dataset import GDC_Bladder_Tumor_Dataset
from datasets_loader.PANDA_dataset import PANDA_Dataset
from losses import LDAMLoss
from networks.Baseline_Model import Baseline1Modality, Baseline2Modality2MLP, Baseline3Modality2MLP
from networks.McacNet import McacNet

from util import AverageMeter, save_result, adjust_learning_rate, warmup_learning_rate, accuracy, set_optimizer, \
    save_model, statistical_BreakHis_case_acc, statistical_BladderTumor_case_acc, \
    statistical_BladderTumor_patient_cognition_rate, statistical_BreakHis_patient_cognition_rate, \
    statistical_GDC_Bladder_Tumor_case_acc, statistical_GDC_Bladder_Tumor_patient_cognition_rate

from sklearn.metrics import cohen_kappa_score

from torch.cuda.amp import autocast as autocast, GradScaler

try:
    import apex
    from apex import amp, optimizers
except ImportError:
    pass


def parse_option():
    parser = argparse.ArgumentParser('argument for training')

    parser.add_argument('--print_freq', type=int, default=1,
                        help='print frequency')
    parser.add_argument('--save_freq', type=int, default=10,
                        help='save frequency')
    parser.add_argument('--batch_size', type=int, default=256,
                        help='batch_size')
    parser.add_argument('--num_workers', type=int, default=32,
                        help='num of workers to use')
    parser.add_argument('--epochs', type=int, default=200,
                        help='number of training epochs')

    # optimization
    parser.add_argument('--learning_rate', type=float, default=0.1,
                        help='learning rate')
    parser.add_argument('--lr_decay_epochs', type=str, default='25, 50, 75, 100, 125, 150, 175',  # '15,30,45,60,70,80,90,100,110,120,130,140'
                        help='where to decay lr, can be a list')
    parser.add_argument('--lr_decay_rate', type=float, default=0.5,
                        help='decay rate for learning rate')
    parser.add_argument('--weight_decay', type=float, default=1e-4,
                        help='weight decay')
    parser.add_argument('--momentum', type=float, default=0.7,
                        help='momentum')

    parser.add_argument('--model', type=str, default='Baseline_Model',
                        choices=['Baseline_Model', 'McacNet'])
    parser.add_argument('--backbone', type=str, default='vanillanet',
                        choices=['resnet', 'efficientnet', 'se_resnet', 'vanillanet', 'se_vanillanet', 'FSConv', 'Custom3'])
    parser.add_argument('--backbone_depth', type=int, default=6,
                        choices=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 18, 34, 50, 101, 152])
    parser.add_argument('--no_cuda', action='store_true', help='If true, cuda is not used.')
    parser.set_defaults(no_cuda=False)

    # dataset
    parser.add_argument('--dataset', type=str, default='PANDA',
                        choices=['BladderTumor', 'BreakHis', 'GDC_Bladder_Tumor', 'PANDA', 'ARVANITI'],
                        help='dataset')
    # BladderTumor dataset setting
    parser.add_argument('--BladderTumor_dir', type=str,
                        help='BladderTumor dataset dir')
    parser.add_argument('--BladderTumor_img_size', type=int, default=512, choices=[256, 512, 1024],
                        help='BreakHis dataset img size')
    # GDC_Bladder_Tumor dataset setting
    parser.add_argument('--GDC_Bladder_Tumor_dir', type=str,
                        help='GDC_Bladder_Tumor dataset dir')
    parser.add_argument('--GDC_Bladder_Tumor_img_size', type=int, default=1024, choices=[256, 512, 1024],
                        help='GDC_Bladder_Tumor dataset img size')
    # BreakHis dataset setting
    parser.add_argument('--BreakHis_dir', type=str,
                        help='BreakHis dataset dir')
    parser.add_argument('--BreakHis_fold', type=int, default=1, choices=[1, 2, 3, 4],
                        help='BreakHis dataset mag')
    parser.add_argument('--BreakHis_mag', type=int, default=40, choices=[40, 100, 200, 400],
                        help='BreakHis dataset mag')
    # PANDA dataset setting
    parser.add_argument('--PANDA_dir', type=str,
                        help='PANDA dataset dir')
    parser.add_argument('--PANDA_fold', type=int, default=1, choices=[1, 2, 3, 4], 
                        help='PANDA dataset mag')
    parser.add_argument('--PANDA_img_size', type=int, default=256, choices=[224, 256],
                        help='PANDA dataset random crop image size')
    parser.add_argument('--PANDA_train_set_file_dir', type=str,
                        help='PANDA dataset train set file dir')
    parser.add_argument('--PANDA_test_set_file_dir', type=str,
                        help='PANDA dataset test set file dir')
    # ARVANITI dataset setting
    parser.add_argument('--ARVANITI_dir', type=str,
                        help='ARVANITI dataset dir')
    parser.add_argument('--ARVANITI_fold', type=int, default=1, choices=[1, 2, 3, 4],
                        help='ARVANITI dataset mag')
    parser.add_argument('--ARVANITI_img_size', type=int, default=256, choices=[224, 256],
                        help='ARVANITI dataset random crop image size')
    parser.add_argument('--ARVANITI_train_set_file_dir', type=str,
                        help='ARVANITI dataset train set file dir')
    parser.add_argument('--ARVANITI_test_set_file_dir', type=str,
                        help='ARVANITI dataset test set file dir')

    # ['original', 'eosin', 'hematoxylin']
    parser.add_argument('--modality_list', type=list, default=['original', 'eosin', 'hematoxylin'],
                        help='modality_list')

    # other setting
    parser.add_argument('--cosine', action='store_true',
                        help='using cosine annealing')
    parser.add_argument('--syncBN', action='store_true',
                        help='using synchronized batch normalization')
    parser.add_argument('--warm', action='store_true',
                        help='warm-up for large batch training')

    opt = parser.parse_args()

    # set the path according to the environment
    opt.model_path = f'./save/train_end2end/{opt.dataset}_models'
    opt.tensorboard_path = f'./save/train_end2end/{opt.dataset}_tensorboard'
    opt.result_path = f'./save/train_end2end/{opt.dataset}_result'

    iterations = opt.lr_decay_epochs.split(',')
    opt.lr_decay_epochs = list([])
    for it in iterations:
        opt.lr_decay_epochs.append(int(it))

    now_time = time.strftime('%Y-%m-%d_%H-%M-%S', time.localtime())

    modality_list_name = ''
    for modality_name in opt.modality_list:
        modality_list_name = modality_list_name + '_' + modality_name

    if opt.dataset == 'BladderTumor':
        opt.model_name = f'{opt.BladderTumor_img_size}' \
                         f'{opt.model}_{opt.backbone}_{opt.backbone_depth}{modality_list_name}_' \
                         f'lr_{opt.learning_rate}_bsz_{opt.batch_size}_epochs_{opt.epochs}_{now_time}'
    elif opt.dataset == 'BreakHis':
        opt.model_name = f'{opt.BreakHis_mag}X_{opt.BreakHis_fold}' \
                         f'{opt.model}_{opt.backbone}_{opt.backbone_depth}{modality_list_name}_' \
                         f'lr_{opt.learning_rate}_bsz_{opt.batch_size}_epochs_{opt.epochs}_{now_time}'
    elif opt.dataset == 'GDC_Bladder_Tumor':
        opt.model_name = f'{opt.GDC_Bladder_Tumor_img_size}' \
                         f'{opt.model}_{opt.backbone}_{opt.backbone_depth}{modality_list_name}_' \
                         f'lr_{opt.learning_rate}_bsz_{opt.batch_size}_epochs_{opt.epochs}_{now_time}'
    elif opt.dataset == 'PANDA':
        opt.model_name = f'{opt.model}_{opt.backbone}_{opt.backbone_depth}{modality_list_name}_{opt.PANDA_img_size}_' \
                         f'lr_{opt.learning_rate}_bsz_{opt.batch_size}_epochs_{opt.epochs}_{now_time}'
    elif opt.dataset == 'ARVANITI':
        opt.model_name = f'{opt.model}_{opt.backbone}_{opt.backbone_depth}{modality_list_name}_{opt.ARVANITI_img_size}_' \
                         f'lr_{opt.learning_rate}_bsz_{opt.batch_size}_epochs_{opt.epochs}_{now_time}'
    if opt.cosine:
        opt.model_name = f'{opt.model_name}_cosine'

    # warm-up for large-batch training,
    if opt.batch_size > 256:
        opt.warm = True
    if opt.warm:
        opt.model_name = f'{opt.model_name}_warm'
        opt.warmup_from = 0.01
        opt.warm_epochs = 10
        if opt.cosine:
            eta_min = opt.learning_rate * (opt.lr_decay_rate ** 3)
            opt.warmup_to = eta_min + (opt.learning_rate - eta_min) * (
                    1 + math.cos(math.pi * opt.warm_epochs / opt.epochs)) / 2
        else:
            opt.warmup_to = opt.learning_rate

    opt.tensorboard_folder = os.path.join(opt.tensorboard_path, opt.model_name)
    if not os.path.isdir(opt.tensorboard_folder):
        os.makedirs(opt.tensorboard_folder)

    opt.save_folder = os.path.join(opt.model_path, opt.model_name)
    if not os.path.isdir(opt.save_folder):
        os.makedirs(opt.save_folder)

    opt.result_folder = os.path.join(opt.result_path, opt.model_name)
    if not os.path.isdir(opt.result_folder):
        os.makedirs(opt.result_folder)

    if opt.dataset == 'BladderTumor' or opt.dataset == 'BreakHis' or opt.dataset == 'GDC_Bladder_Tumor':
        opt.n_cls = 2
    elif opt.dataset == 'PANDA' or opt.dataset == 'ARVANITI':
        opt.n_cls = 4
    else:
        raise ValueError(f'dataset not supported: {opt.dataset}')

    return opt


def set_loader(opt):

    if opt.dataset == 'BladderTumor':
        images_dir = os.path.join(opt.BladderTumor_dir, 'crop_' + str(opt.BladderTumor_img_size))
        train_dataset = BladderTumorDataset(images_dir=images_dir,
                                            label_file_dir=os.path.join(images_dir, 'train.txt'),
                                            modality_list=opt.modality_list)
        val_dataset = BladderTumorDataset(images_dir=images_dir,
                                          label_file_dir=os.path.join(images_dir, 'test.txt'),
                                          modality_list=opt.modality_list)
    elif opt.dataset == 'GDC_Bladder_Tumor':
        # images_dir = os.path.join(opt.BladderTumor_dir, 'crop_' + str(opt.BladderTumor_img_size))
        images_dir = opt.GDC_Bladder_Tumor_dir
        train_dataset = GDC_Bladder_Tumor_Dataset(images_dir=images_dir,
                                                  label_file_dir=os.path.join(images_dir,
                                                                              'train_test_file_class_unbalance',
                                                                              'train_balance.txt'),
                                                  modality_list=opt.modality_list)
        val_dataset = GDC_Bladder_Tumor_Dataset(images_dir=images_dir,
                                                label_file_dir=os.path.join(images_dir,
                                                                            'train_test_file_class_unbalance',
                                                                            'test_balance.txt'),
                                                modality_list=opt.modality_list)
    elif opt.dataset == 'BreakHis':
        train_label_file = os.path.join(opt.BreakHis_dir,
                                        str(opt.BreakHis_mag) + 'X',
                                        'train_' + str(opt.BreakHis_mag) + 'X_' + str(opt.BreakHis_fold) + '.txt')
        train_dir = train_label_file.split('train_')[0]
        train_dataset = BreakHisDataset(images_dir=train_dir,
                                        modality_list=opt.modality_list,
                                        label_file=train_label_file)

        test_label_file = train_label_file.replace('train_', "test_")
        test_dir = train_dir
        val_dataset = BreakHisDataset(images_dir=test_dir,
                                      modality_list=opt.modality_list,
                                      label_file=test_label_file)
    elif opt.dataset == 'PANDA':

        train_dataset = PANDA_Dataset(images_dir=opt.PANDA_dir,
                                      label_file_dir=opt.PANDA_train_set_file_dir,
                                      modality_list=opt.modality_list,
                                      is_train=True,
                                      crop_img_size=(opt.PANDA_img_size, opt.PANDA_img_size),
                                      is_SupCon=False)
        val_dataset = PANDA_Dataset(images_dir=opt.PANDA_dir,
                                    label_file_dir=opt.PANDA_test_set_file_dir,
                                    modality_list=opt.modality_list,
                                    is_train=False,
                                    crop_img_size=(opt.PANDA_img_size, opt.PANDA_img_size),
                                    is_SupCon=False)
    elif opt.dataset == 'ARVANITI':

        train_dataset = ARVANITI_Dataset(images_dir=opt.ARVANITI_dir,
                                         label_file_dir=opt.ARVANITI_train_set_file_dir,
                                         modality_list=opt.modality_list,
                                         is_train=True,
                                         crop_img_size=(opt.ARVANITI_img_size, opt.ARVANITI_img_size),
                                         is_SupCon=False)
        val_dataset = ARVANITI_Dataset(images_dir=opt.ARVANITI_dir,
                                       label_file_dir=opt.ARVANITI_test_set_file_dir,
                                       modality_list=opt.modality_list,
                                       is_train=False,
                                       crop_img_size=(opt.ARVANITI_img_size, opt.ARVANITI_img_size),
                                       is_SupCon=False)
    else:
        raise ValueError(opt.dataset)

    train_loader = DataLoader(dataset=train_dataset, batch_size=opt.batch_size, shuffle=True,
                              num_workers=opt.num_workers, pin_memory=True)
    val_loader = DataLoader(dataset=val_dataset, batch_size=opt.batch_size, shuffle=False,
                            num_workers=opt.num_workers, pin_memory=True)

    return train_loader, val_loader


def set_model(opt):
    modality_num = len(opt.modality_list)
    if opt.model == 'Baseline_Model':
        if 1 == modality_num:
            model = Baseline1Modality(model_name=opt.backbone, model_depth=opt.backbone_depth,
                                      num_classes=opt.n_cls)
        elif 2 == modality_num:
            model = Baseline2Modality2MLP(model_name=opt.backbone, model_depth=opt.backbone_depth,
                                          num_classes=opt.n_cls)
        elif 3 == modality_num:
            model = Baseline3Modality2MLP(model_name=opt.backbone, model_depth=opt.backbone_depth,
                                          num_classes=opt.n_cls)
        else:
            raise ValueError(f'The number of modes is incorrect: {opt.model}, {opt.backbone}, {opt.modality_list}')
    elif opt.model == 'McacNet':
        if 2 == modality_num or 3 == modality_num:
            model = McacNet(model_type=opt.backbone, model_depth=opt.backbone_depth,
                            classifiy_head_type='mlp', num_classes=opt.n_cls, modality_num=modality_num)
        else:
            raise ValueError(f'The number of modes is incorrect: {opt.model}, {opt.backbone}, {opt.modality_list}')
    else:
        raise ValueError(f'model not supported: {opt.model}')

    criterion = torch.nn.CrossEntropyLoss()

    # enable synchronized Batch Normalization
    if opt.syncBN:
        model = apex.parallel.convert_syncbn_model(model)

    if torch.cuda.is_available():
        if torch.cuda.device_count() > 1:
            model = torch.nn.DataParallel(model)
        model = model.cuda()
        criterion = criterion.cuda()
        cudnn.benchmark = True

    return model, criterion


def train(train_loader, model, ce_criterion, optimizer, epoch, opt):
    """one epoch training"""
    model.train()

    ce_loss_meter = AverageMeter()
    acc_meter = AverageMeter()

    # 0------------------------------
    img_name_list = []
    y_pred = []
    y_true = []
    y_pred_one_hot = []
    # 0------------------------------

    end = time.time()
    for idx, (images, labels, names) in enumerate(train_loader):

        images = images.cuda(non_blocking=True)
        labels = labels.cuda(non_blocking=True)
        bsz = labels.shape[0]

        # warm-up learning rate
        warmup_learning_rate(opt, epoch, idx, len(train_loader), optimizer)

        output = model(images)
        # compute loss
        ce_loss = ce_criterion(output, labels)

        # update metric
        ce_loss_meter.update(ce_loss.item(), bsz)
        acc = accuracy(output, labels)
        acc_meter.update(acc[0].item(), bsz)

        # 1---------------------------------------------
        img_name_list.extend(names)
        batch_y_pred_one_hot = output.cpu().tolist()
        batch_y_pred = output.argmax(1).cpu().numpy()
        batch_y_true = labels.cpu().numpy()
        y_pred.extend(batch_y_pred)
        y_true.extend(batch_y_true)
        y_pred_one_hot.extend(batch_y_pred_one_hot)
        # 1--------------------------------------------

        # SGD
        optimizer.zero_grad()
        ce_loss.backward()
        optimizer.step()

        # print info
        if (idx + 1) % opt.print_freq == 0:
            print('Train: [{0}][{1}/{2}]\t'
                  'CE_Loss {ce_loss_meter.val:.3f} ({ce_loss_meter.avg:.3f})\t'
                  'Accuracy {acc_meter.val:.3f} ({acc_meter.avg:.3f})'.format(
                   epoch, idx + 1, len(train_loader), ce_loss_meter=ce_loss_meter, acc_meter=acc_meter))
            sys.stdout.flush()

    kappa_scores = cohen_kappa_score(y_true, y_pred, weights='quadratic')
    print(f'Accuracy: {acc_meter.avg}, Kappa_score: {kappa_scores}')
    print(f'Train epoch time-consuming: {time.strftime("%H:%M:%S", time.gmtime(time.time() - end))}')

    result_df = pd.DataFrame(y_pred_one_hot)
    result_df.insert(0, 'image_name', img_name_list)
    result_df.insert(1, 'y_true', y_true)
    result_df.insert(2, 'y_pred', y_pred)
    result_df.set_index(['image_name'], inplace=True)

    return ce_loss_meter.avg, acc_meter.avg, kappa_scores, result_df


def validate(val_loader, model, ce_criterion, opt):
    """validation"""
    model.eval()

    ce_loss_meter = AverageMeter()
    acc_meter = AverageMeter()

    # 0------------------------------
    img_name_list = []
    y_pred = []
    y_true = []
    y_pred_one_hot = []
    # 0------------------------------

    with torch.no_grad():
        end = time.time()
        for idx, (images, labels, names) in enumerate(val_loader):
            images = images.cuda()
            labels = labels.cuda()
            bsz = labels.shape[0]

            # forward
            output = model(images)

            ce_loss = ce_criterion(output, labels)

            # update metric
            ce_loss_meter.update(ce_loss.item(), bsz)
            acc = accuracy(output, labels)
            acc_meter.update(acc[0].item(), bsz)

            # 1---------------------------------------------
            img_name_list.extend(names)
            batch_y_pred_one_hot = output.cpu().tolist()
            batch_y_pred = output.argmax(1).cpu().numpy()
            batch_y_true = labels.cpu().numpy()
            y_pred.extend(batch_y_pred)
            y_true.extend(batch_y_true)
            y_pred_one_hot.extend(batch_y_pred_one_hot)
            # 1--------------------------------------------

            if idx % opt.print_freq == 0:
                print('Test: [{0}/{1}]\t'
                      'CE_Loss {ce_loss_meter.val:.4f} ({ce_loss_meter.avg:.4f})\t'
                      'Accuracy {acc_meter.val:.3f} ({acc_meter.avg:.3f})'.format(idx, len(val_loader),
                                                                                  ce_loss_meter=ce_loss_meter,
                                                                                  acc_meter=acc_meter))
        print(f'Test epoch time-consuming: {time.strftime("%H:%M:%S", time.gmtime(time.time() - end))}')

    kappa_scores = cohen_kappa_score(y_true, y_pred, weights='quadratic')
    print(f'* Accuracy: {acc_meter.avg}, Kappa_score: {kappa_scores}')

    result_df = pd.DataFrame(y_pred_one_hot)
    result_df.insert(0, 'image_name', img_name_list)
    result_df.insert(1, 'y_true', y_true)
    result_df.insert(2, 'y_pred', y_pred)
    result_df.set_index(['image_name'], inplace=True)

    return ce_loss_meter.avg, acc_meter.avg, kappa_scores, result_df


def main():
    best_acc = 0
    opt = parse_option()

    # build data loader
    train_loader, val_loader = set_loader(opt)

    # build model and criterion
    model, ce_criterion = set_model(opt)

    # build optimizer
    optimizer = set_optimizer(opt, model)

    # tensorboard
    logger = tb_logger.Logger(logdir=opt.tensorboard_folder, flush_secs=2)

    # if opt.dataset == 'BreakHis':
    #     statistical_case_acc = statistical_BreakHis_case_acc
    #     statistical_patient_cognition_rate = statistical_BreakHis_patient_cognition_rate
    # elif opt.dataset == 'BladderTumor':
    #     statistical_case_acc = statistical_BladderTumor_case_acc
    #     statistical_patient_cognition_rate = statistical_BladderTumor_patient_cognition_rate
    # elif opt.dataset == 'GDC_Bladder_Tumor':
    #     statistical_case_acc = statistical_GDC_Bladder_Tumor_case_acc
    #     statistical_patient_cognition_rate = statistical_GDC_Bladder_Tumor_patient_cognition_rate
    # elif opt.dataset == 'PANDA':
    #     pass
    # else:
    #     raise ValueError(f'dataset not supported: {opt.dataset}')

    # training routine
    for epoch in range(1, opt.epochs + 1):
        adjust_learning_rate(opt, optimizer, epoch)

        # train for one epoch
        train_loss, train_acc, train_kappa_score, train_result_df = train(train_loader, model, ce_criterion, optimizer, epoch, opt)

        # train_case_acc, train_same_count, train_case_num = statistical_case_acc(img_name_list=train_result_list[0],
        #                                                                         y_true=train_result_list[1],
        #                                                                         y_pred=train_result_list[2])

        # train_pcr = statistical_patient_cognition_rate(img_name_list=train_result_list[0],
        #                                                y_true=train_result_list[1],
        #                                                y_pred=train_result_list[2])
        #
        # print(f'train_pcr: {train_pcr}, train_case_acc: {train_case_acc}, '
        #       f'train_same_count: {train_same_count}, train_case_num: {train_case_num}')

        # tensorboard logger
        # logger.log_value('train_case_acc', train_case_acc, epoch)
        # logger.log_value('train_pcr', train_pcr, epoch)
        logger.log_value('train_loss', train_loss, epoch)
        logger.log_value('train_acc', train_acc, epoch)
        logger.log_value('train_kappa_score', train_kappa_score, epoch)
        logger.log_value('learning_rate', optimizer.param_groups[0]['lr'], epoch)

        # evaluation
        val_loss, val_acc, val_kappa_score, val_result_df = validate(val_loader, model, ce_criterion, opt)

        # val_case_acc, val_same_count, val_case_num = statistical_case_acc(img_name_list=val_result_list[0],
        #                                                                   y_true=val_result_list[1],
        #                                                                   y_pred=val_result_list[2])

        # val_pcr = statistical_patient_cognition_rate(img_name_list=val_result_list[0],
        #                                              y_true=val_result_list[1],
        #                                              y_pred=val_result_list[2])
        # print(f'val_pcr: {val_pcr}, val_case_acc: {val_case_acc}, '
        #       f'val_same_count: {val_same_count}, val_case_num: {val_case_num}')
        # logger.log_value('val_case_acc', val_case_acc, epoch)
        # logger.log_value('val_pcr', val_pcr, epoch)
        logger.log_value('val_loss', val_loss, epoch)
        logger.log_value('val_acc', val_acc, epoch)
        logger.log_value('val_kappa_score', val_kappa_score, epoch)

        if val_acc > best_acc:
            best_acc = val_acc

        # train_result_df.to_csv(os.path.join(opt.result_folder,
        #                                     'train_result_epoch_' + str(epoch) +
        #                                     '_train-acc_' + str(round(train_acc, 2)) +
        #                                     '_val-kappa-score_' + str(round(train_kappa_score, 2)) +
        #                                     '.csv'))

        val_result_df.to_csv(os.path.join(opt.result_folder,
                                          'test_result_epoch_' + str(epoch) +
                                          '_val-acc_' + str(round(val_acc, 2)) +
                                          '_val-kappa-score_' + str(round(val_kappa_score, 2)) +
                                          '.csv'))

        if epoch % opt.save_freq == 0:
            save_file = os.path.join(
                opt.save_folder, 'ckpt_epoch_{epoch}.pth'.format(epoch=epoch))
            save_model(model, optimizer, opt, epoch, save_file)

    # save the last model
    save_file = os.path.join(
        opt.save_folder, 'last.pth')
    save_model(model, optimizer, opt, opt.epochs, save_file)

    print('best accuracy: {:.2f}'.format(best_acc))


if __name__ == '__main__':
    main()
